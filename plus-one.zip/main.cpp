/******************************************************************************

                              Online C++ Debugger.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Debug" button to debug it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    int i, digits[100],n;
    cin>>n;
    for(i=0;i<n;i++){
        cin>>digits[i];
        
    }
    for(i=0;i<n;i++){
        if(i<n-1){
            cout<<digits[i];
             cout<<",";
        }
        else if( i==n-1){
            digits[i]=digits[i]+1;
            cout<<digits[i];
            
        }
    }
    

    return 0;
}
